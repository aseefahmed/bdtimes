@extends('layouts.admin.dashboard')

@section('content')
gfdsgfdsg
@endsection