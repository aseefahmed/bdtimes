<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>বাংলাদেশ টাইমস</title>
	<link href="{{ url('public/css/frontend/all.css') }}" rel="stylesheet">
    
	<!--link href="{{ url('public/assets/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ url('public/assets/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ url('public/assets/css/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ url('public/assets/css/magnific-popup.css') }}" rel="stylesheet">
    <link href="{{ url('public/assets/css/dycalender.min.css') }}" rel="stylesheet">
    <link href="{{ url('public/assets/css/style.css') }}" rel="stylesheet">
    <link href="{{ url('public/assets/css/responsive.css') }}" rel="stylesheet">
    <link href="{{ url('public/plugins/select2/css/select2.min.css') }}" rel="stylesheet">
	<link href="{{ url('public/plugins/bootstrap-fileinput/css/fileinput.css') }}" rel="stylesheet" type="text/css"-->

    <style>
     #status{
    	width:100%;
    	height:100%;
    	position:fixed;
    	overflow:hidden;
    	z-index:9999;
    	background:rgba(255,255,255,1.00);
    }
    #preloader{
    	top:50%;
    	left:50%;
    	width:128px;
    	height:125px;
    	position:absolute;
    	margin:-63px 0 0 -64px;
    }
    </style>
</head>

<body ng-app="myApp">
    <div id="status">
		<div id="preloader" class="preloader">
			<img src="{{asset('public/images/Blocks.gif')}}" alt="Preloader" />
		</div>
	</div>
    <div style="visibility:hidden;" id="main_body">
    <!-- off canvas menu -->
    <div class="off-canvas-overlay"></div>
    <div class="off-canvas-menu">
        <span class="menu-close"><i class="fa fa-close"></i></span>
		
        <ul>
            <li>
				<a href="{{url('category/national')}}">বাংলাদেশ</a>
				<a href="{{url('category/international')}}">আন্তর্জাতিক</a>
				<a href="{{url('category/economics')}}">অর্থনীতি</a>
				<a href="{{url('category/entertainment')}}">বিনোদন</a>
				<a href="{{url('category/education')}}">শিক্ষা</a>
				<a href="{{url('category/science')}}">বিজ্ঞান ও প্রযুক্তি</a>
				<a href="{{url('category/crime')}}">ক্রাইম</a>
				<a href="{{url('category/travel')}}">ভ্রমণ </a>
				<a href="{{url('category/politics')}}">রাজনীতি   </a>
				<a href="{{url('category/lifestyle')}}">লাইফ স্টাইল    </a>
				<a href="{{url('category/health')}}">স্বাস্থ্য  </a>
				<a href="{{url('category/legal-aids')}}">আইনী সাহায্য     </a>
				<a href="{{url('category/islamic')}}">ইসলামিক </a>
				<a href="{{url('category/probash')}}">প্রবাস </a>
				<a href="{{url('category/history')}}">ইতিহাস   </a>
				<a href="{{url('category/nreegoshthi')}}">নৃগোষ্ঠী  </a>
				<a href="{{url('category/uthan-boithok')}}">উঠান বৈঠক  </a>
				<a href="{{url('category/vedio-gallery')}}">ভিডিও গ্যালারী      </a>
			</li>
				
        </ul>
    </div>

    <!-- header top area -->
    <div class="header-top-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-6 col-xs-3 text-left">
                    <div class="menu-toggle-btn">
                        <a href="" class="menu-trigger">
                            <i class="fa fa-bars"></i>
                        </a>
							&nbsp; 
							@if(isset(Auth::user()->id))
								<a href="{{url('/dashboard')}}" style="color: red; font-weight: bold;cursor: pointer; background-color: transparent; font-size: 16px;padding: 0px; margin-left: 0px;"><i class="fa fa-book text-primary"></i> একাউন্ট<span>  | 
								&nbsp;<a href="{{url('/logout')}}" style="color: red; font-weight: bold;cursor: pointer; background-color: transparent; font-size: 16px;padding: 0px; margin-left: 0px;"><i class="fa fa-sign-out text-primary"></i> বের হউন <span>
							@else 
								<a href="{{url('/login')}}" style="color: red; font-weight: bold;cursor: pointer; background-color: transparent; font-size: 16px;padding: 0px; margin-left: 0px;"><i class="fa fa-user text-primary"></i> প্রবেশ </<a> | 
							     &nbsp;<a href="{{url('/registration')}}"  style="color: red; font-weight: bold;cursor: pointer; background-color: transparent; font-size: 16px;padding: 0px; margin-left: 0px;"><i class="fa fa-key text-primary"></i> নিবন্ধন </<a> 
							@endif 
							
							&nbsp; 
							&nbsp; 
							&nbsp; 
							&nbsp; 
								<a href="{{url('setLanguage/bangla/'.Route::currentRouteName())}}" style="color: darkblue; font-weight: bold;cursor: pointer; background-color: transparent; font-size: 16px;padding: 0px; margin-left: 0px;"><img src="http://cdn.wonderfulengineering.com/wp-content/uploads/2015/07/Bangladesh-Flag-2.png" width="20px"> Bangla<span>&nbsp; | &nbsp;
								<br>&nbsp; 
								&nbsp;<a href="{{url('setLanguage/english/'.Route::currentRouteName())}}" style="color: darkblue; font-weight: bold;cursor: pointer; background-color: transparent; font-size: 16px;padding: 0px; margin-left: 0px;"><img src="http://img.freeflagicons.com/thumb/round_icon/united_kingdom/united_kingdom_640.png" width="20px"> English<span>
							 
							<br>
							<span id="weather_id" class="text-success">আজকের তাপমাত্রা : </span>
							
							
						</span>
                    </div>
                </div>

                <div class="col-sm-6 col-xs-9 text-right">
                    <div class="logo">
                        <a href="{{url('/')}}"><img src="{{ asset('public/assets/img/logo.png')}}" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--  Marquee text area  -->
    <div class="marquee-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="marquee-wrap">
                        <div class="marquee-heading text-center">
                            <h3>সদ্যপ্রাপ্ত:</h3>
                        </div>
                        <div class="marquee-text marquee">
                            <p><a href="{{ url('news/front/details/'.$breaking_news[0]->id) }}">{{ $breaking_news[0]->title }}</a> | <a href="{{ url('news/front/details/'.$breaking_news[1]->id) }}">{{ $breaking_news[1]->title }}</a> | <a href="{{ url('news/front/details/'.$breaking_news[2]->id) }}">{{ $breaking_news[2]->title }}</a></p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
	<style type="text/css">  
	  .centered {
		position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		transform: -webkit-translate(-50%, -50%);
		transform: -moz-translate(-50%, -50%);
		transform: -ms-translate(-50%, -50%);
		color:darkred;
	  }
	</style>
	
	@yield('content')
    <!-- footer area -->
    <div class="footer-area">
        <div class="container">
            <div class="row">
				<div class="col-sm-3 col-xs-12">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="{{url('category/national')}}">বাংলাদেশ</a></li>
                            <li><a href="{{url('category/international')}}">আন্তর্জাতিকি</a></li>
                            <li><a href="{{url('category/economics')}}">অর্থনীতি</a></li>
                            <li><a href="{{url('category/legal-aids')}}">আইনী সাহায্য  </a></li>
                            <li><a href="{{url('category/nreegoshthi')}}">নৃগোষ্ঠী  </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="{{url('category/entertainment')}}">বিনোদন</a></li>
                            <li><a href="{{url('category/education')}}">শিক্ষা</a></li>
                            <li><a href="{{url('category/science')}}">বিজ্ঞান ও প্রযুক্তি </a></li>
                            <li><a href="{{url('category/islamic')}}">ইসলামিক </a></li>
                            <li><a href="{{url('category/uthan-boithok')}}">উঠান বৈঠক  </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="{{url('/')}}">রাজনীতি</a></li>
                            <li><a href="{{url('category/crime')}}">ক্রাইম</a></li>
                            <li><a href="{{url('category/travel')}}">ভ্রমন</a></li>
                            <li><a href="{{url('category/probash')}}">প্রবাস </a></li>
                            <li><a href="{{url('category/vedio-gallery')}}">ভিডিও গ্যালারী      </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-3 col-xs-12">
                    <div class="footer-menu">
                        <ul>
                            <li><a href="{{url('/')}}">প্রচ্ছদ </a></li>
                            <li><a href="{{url('/archives')}}">আর্কাইভ</a></li>
                            <li><a href="{{url('category/lifestyle')}}">লাইফ স্টাইল </a></li>
                            <li><a href="{{url('category/health')}}">স্বাস্থ্য  </a></li>
                            <li><a href="{{url('category/history')}}">ইতিহাস   </a></li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

	<!----Modal------>
	<div>
		<div class="modal fade" id="ad-upload-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
		 
		  <div class="container" style="background-color: white; margin-top: 20px;">
				<div class="loginmodal-container">
					<h1 class="well text-center" style="margin-top: 10px;"> Upload Banner</h1><br>
				
				
				<div class="row">
					<form class="form-horizontal" id="myForm" method="POST" enctype="multipart/form-data">
					<input type="hidden" name="banner_id" id="banner_id">
					<input type="hidden" name="banner_page" id="banner_page">
					{{ csrf_field() }}
						<div class="form-group">
						  <label class="control-label col-sm-2" for="email">Banner Name:</label>
						  <div class="col-sm-6">
							<input type="text" class="form-control" id="banner_name" placeholder="Banner Name" name="banner_name">
						  </div>
						</div>
						<div class="form-group">
						  <label class="control-label col-sm-2" for="pwd">External Link:</label>
						  <div class="col-sm-6">          
							<input type="text" class="form-control" id="external_link" placeholder="External Link" name="external_link">
						  </div>
						</div>
						<div class="form-group">
						  <label class="control-label col-sm-2" for="pwd">Browse Image:</label>
						  <div class="col-sm-6">          
							<input type="file" class="form-control fileinputjs" id="photo" placeholder="Image" name="photo">
						  </div>
						</div>
						<div class="form-group">        
						  <div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-success" id="uploadBanner">Upload</button>
						  </div>
						</div>
					  </form>
				</div>
				<div style="height: 10px;"></div>
				<div id="divToHid" style="display:none;background-color: white;">
					<button style='margin-top: 10px;' class='col-md-6 btn btn-success'  id='selectImageAd'>Select</button>
					<button style='margin-top: 10px;' class='col-md-6 btn btn-primary'  id='undoImageAd'>Undo</button>
				</div>
				<div id="adImg"></div>
			</div>
		</div>
	</div>
	</div>
	<script src="{{ url('public/js/frontend/all.js') }}"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
    <!--script src="{{ url('public/assets/js/jquery.min.js') }}"></script>
	
	<script src="{{ url('public/assets/js/bootstrap.min.js') }}"></script>
    <script src="{{ url('public/assets/js/custom.js') }}"></script>
    <script src="{{ url('public/plugins/select2/js/select2.min.js') }}"></script>
	<script src="{{ url('public/plugins/bootstrap-fileinput/js/fileinput.min.js') }}" type="text/javascript"></script>
	<script src="{{ url('public/assets/js/owl.carousel.min.js') }}"></script>
	<script src="{{ url('public/assets/js/jquery.magnific-popup.min.js') }}"></script>
	<script src="{{ url('public/assets/js/jquery.sticky.js') }}"></script-->
	
    <script src="{{ url('public/assets/js/controllers/main_controllers.js') }}"></script>
    <script src="{{ url('public/assets/js/main.js') }}"></script>
	@yield('js_libs')
	<script>
	$(document).ready(function(){
		$.ajax({
			url: "http://api.openweathermap.org/data/2.5/forecast/daily?mode=json&q=Dhaka&lang=en&APPID=e90ad8bee96d555950989a20552a6002",
			method: "GET",
			contentType: false,
			cache: false,
			processData:false,
			success: function(result){
				weather = Math.round(result.list[0].temp.day-275.15)+"<sup>o</sup>C";
				$('#weather_id').append(weather);
				
			}
		}).fail(function(result){
			console.log(result.list[0])
		});
	    $("#status").css('display', 'none')
    	$("#main_body").css('visibility', 'visible');
		if($('.select2js').length > 0)
		{
			$('.select2js').select2();
		}
		if($('.calendarjs').length > 0)
		{
			$('.calendarjs').datepicker({
				changeMonth: true,
				changeYear: true,
				dateFormat: 'mm/dd/yy',
				@if(isset($month))
					defaultDate: "{{$month}}/{{$day}}/{{$year}}",
				@endif
				onSelect: function (date) {
					window.location.href = "{{url('archives')}}/"+date
				}
			});
		}
		if($('.fileinputjs').length > 0)
		{
			$('.fileinputjs').fileinput();
		}
		$('#submit_comment_btn').click(function(){
			$("#ajax_loader").css('display', 'block');
			formData = new FormData($("#myForm")[0]);
			$.ajax({
				url: "{{ url('submitComment') }}",
				method: "POST",
				data: formData,
				contentType: false,
				cache: false,
				processData:false,
				success: function(result){
					
					$("#ajax_loader").css('display', 'none');
					str = "<div class='single-demo-comment'>";
					str += "<div class='comment-dp'>";
					str += "<img src='{{url('/')}}/"+result.profile_image+"'></div>";
					str += "<div class='comment-meta'>";
					str += "<h3>"+result.name+"</h3>";
					str += "<p>"+result.details+" </p>";
					str += "<p>"+result.date+"</p></div></div>";
															
					$('.demo-comments').prepend(str)
					/* toastr.warning('User has been created successfully!', 'Notification')
					toastr.options.closeButton = true;
					window.location.href = app.host + 'dashboard/'+user_type+'/list'; */
					
				}
			}).fail(function(result){
				console.log(result)
			});
		})
		$('.savePostBtn').click(function(e){
		e.preventDefault();
		$('.savePostBtn').attr('disabled', 'disabled');
		$('#ajax_loader1').css('display', 'inline');
		/* for ( instance in CKEDITOR.instances )
			CKEDITOR.instances[instance].updateElement(); */

		var flag = $(this).attr('flag');
		$('#flag').val(flag);
		console.log(222222);
		console.log($('#news_details'));
		formData = new FormData($("#addNewsForm")[0]);
		console.log(formData)
        $.ajax({
            url: "{{ url('news/add/visitor') }}",
            method: "POST",
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
				console.log(result)
				
				$('#ajax_loader1').css('display', 'none');
                
                window.location.href = "{{ url('dashboard') }}";
            }
        }).fail(function(result){
            console.log(result)
        });
	}); 
		$('#uploadBanner').click(function(){
			formData = new FormData($("#myForm")[0]);
			$.ajax({
				url: "{{url('uploadBanner')}}",
				method: "POST",
				data: formData,
				contentType: false,
				cache: false,
				processData:false,
				success: function(result){
					console.log(result)
					$('.success_div').css('display', 'block');
					$('#success-modal').modal('toggle');
					/* toastr.warning('User has been created successfully!', 'Notification')
					toastr.options.closeButton = true;
					window.location.href = app.host + 'dashboard/'+user_type+'/list'; */
					if(result == 'home'){
						window.location.href = "{{url('/')}}";
					}else{
						window.location.href = "{{url('category')}}/"+result;
					}
				}
			}).fail(function(result){
				console.log(result)
			});

		})
		

		$('#choose_image').change(function(){
			var choose_image = $('#choose_image').val();
			
			var file_id = choose_image.substr(0, choose_image.indexOf('-'));
			var file_name = choose_image.substr(choose_image.indexOf('-')+1);
			
			$('#divToHid').css('display', 'block');
			src = "<img id='choosenImage' file_name='"+file_name+"' style='margin-top: 10px;' src='"+app.frontend+"/public/images/assets/"+file_name+"'>";
			$('#adImg').html(src);
		})
		
		$('#selectImageAd').click(function(){
			banner_id = $('#selectImageAd').attr('banner_id') ;
			page = $('#selectImageAd').attr('page') ;
			image_id = $('#choosenImage').attr('file_name');
			alert(banner_id);dd
			$.ajax({
            url: "ads/changeBanner/"+banner_id+'/'+image_id,
            method: "GET",
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
					console.log(page)
					window.location.href = app.frontend;
				}
			}).fail(function(result){
				console.log(result)
			});
		})
		$('#edit_user').click(function(){
			
			$('#ajax_loader').css('display', 'inline');
			formData = new FormData($("#userDetails")[0]);
			$.ajax({
				url: "{{ url('dashboard/visitor/update') }}",
				method: "POST",
				data: formData,
				contentType: false,
				cache: false,
				processData:false,
				success: function(result){
					console.log(result)
					window.location.href = "{{ url('dashboard') }}";
				}
			}).fail(function(result){
				$('#ajax_loader').css('display', 'none');
				$("#failure_div").delay(3000).fadeOut('slow');
			});
		});
		$('#vote_btn').click(function(e){
			e.preventDefault();
			$('#vote_btn').attr('disabled', 'disabled');
			formData = new FormData($("#myVoteForm")[0]);
			$.ajax({
				url: "{{ url('vote') }}",
				method: "POST",
				data: formData,
				contentType: false,
				cache: false,
				processData:false,
				success: function(result){
					console.log(result)
					$('#vote_btn').attr('disabled', false);
					if(result == -1)
					{
						
						alert('You already participated in this poll');
					}
					else{
						alert('You have successfully submitted your vote.');
					}
				}
			}).fail(function(result){
				$('#vote_btn').attr('disabled', false);
				alert('Error. Submission failed.');
			});
		})
		$('#undoImageAd').click(function(){
			banner_id = $('#undoImageAd').attr('banner_id') ;
			page = $('#undoImageAd').attr('page') ;
			image_id = $('#choosenImage').attr('file_name');
			
			$.ajax({
            url: "ads/undoBanner/"+banner_id+'/'+image_id,
            method: "POST",
            contentType: false,
            cache: false,
            processData:false,
            success: function(result){
					console.log(page)
					window.location.href = app.frontend;
				}
			}).fail(function(result){
				console.log(result)
			});
		})
	})
		
	</script>

</body>

</html>